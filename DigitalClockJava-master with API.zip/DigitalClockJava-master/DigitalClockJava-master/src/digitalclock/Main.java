package digitalclock;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
//Added imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;



public class Main extends JFrame{

    JLabel jlabClock;
    ClockThread clockthread;

    public Main() {
        // Weather information API
        try {
            String weatherDataJson = getWeatherData("Lynchburg"); // This is hard coded
            JSONObject weatherData = new JSONObject(weatherDataJson);
            String weatherDescription = weatherData.getJSONArray("weather").getJSONObject(0).getString("description");
            double temp = weatherData.getJSONObject("main").getDouble("temp");
            JLabel jlabWeather = new JLabel("Weather: " + weatherDescription + ", Temperature: " + temp + "°C" + " in " + "Lynchburg, VA");
            jlabWeather.setFont(new Font("Arial", Font.PLAIN, 40));
            jlabWeather.setForeground(Color.GREEN);
            jlabWeather.setOpaque(true);
            jlabWeather.setBackground(Color.black);
            add(jlabWeather);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Clock
        jlabClock = new JLabel("");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jlabClock.setFont(new Font("Arial", Font.CENTER_BASELINE, 80 ));
        jlabClock.setOpaque(true);
        jlabClock.setBackground(Color.black);
        jlabClock.setForeground(Color.green);
        add(jlabClock);
        setSize(1220, 220);
        setLocationRelativeTo(null);
        clockthread = new ClockThread(this);
        setVisible(true);

    }

    // Get the weather information
    public String getWeatherData(String city) throws Exception {
        String apiKey = "cac82c840164e1961a4284e04fb297d8"; // Replace with your actual API key
        String encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString());
        String apiUrl = "http://api.openweathermap.org/data/2.5/weather?q=" + encodedCity + "&appid=" + apiKey + "&units=metric";
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            result.append(line);
        }
        reader.close();
        return result.toString();
    }

    public static void main(String[] args) {

        new Main();

    }
}
